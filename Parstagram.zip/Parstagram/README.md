# Parstagram - Part II

This is an Instagram clone with a custom Parse backend that allows a user to post photos, view a global photos feed, and add comments!

Time spent: **5** hours spent in total

## User Stories

The following **required** functionality is completed:

- [X] User stays logged in across restarts. (1pt)
- [X] User can log out. (1pt)
- [X] User can view comments on a post. (3pts)
- [X] User can add a new comment. (5pts)

The following **bonus** features are implemented:

- [ ] User can add a profile picture. (2pts)
- [ ] Profile pictures are shown for posts and comments. (2pts)

## Video Walkthrough

Here's a walkthrough of implemented user stories:

![ezgif com-optimize (2)](https://user-images.githubusercontent.com/22580992/75632954-fe88f300-5bce-11ea-9b88-c198a6b92b6e.gif)

## User Stories

The following **required** functionality is completed:

- [X] User sees app icon in home screen and styled launch screen. (1pt)
- [X] User can sign up to create a new account. (1pt)
- [X] User can log in. (1pt)
- [X] User can take a photo, add a caption, and post it to the server. (3pt)
- [X] User can view the last 20 posts. (4pts)

The following **bonus** features are implemented:

- [ ] User can pull to refresh. (1pt)
- [ ] User can load past tweets infinitely. (2pts)

## Video Walkthrough

Here's a walkthrough of implemented user stories:

![ezgif com-optimize-4](https://user-images.githubusercontent.com/22580992/75122191-2de8ae80-5669-11ea-8a46-101ffb3c7894.gif)
